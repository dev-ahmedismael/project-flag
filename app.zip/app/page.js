import Review from "./Review";
import News from "./News";
import Partners from "./Partners";
export default function Home() {
  return (
    <div>
     <Review/>
     <Partners/>
      
      <News/>

    </div>
  
  );
}
