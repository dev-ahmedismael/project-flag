import React from 'react'

function Buttoninfonews(props) {
  return (
    <div>
        <button className='text-[#FFC34C] border border-[#FFC34C] rounded-2xl p-1 w-[120px]'>{props.inside}</button>

    </div>
  )
}

export default Buttoninfonews